# MP Live TH V1

Android client + demo adapter backend for a Thailand marketplace feed.

## Core behavior
- REST initial load.
- Server-Sent Events (SSE) for live arrivals.
- Every merge is sorted by `created_at DESC`, so the newest listing is always first.
- Duplicate IDs are de-duplicated.
- Items <=10 minutes old are marked `ใหม่`.

## Important data-source rule
This project intentionally does **not** contain Facebook session-cookie scraping, CAPTCHA bypassing, anti-bot evasion, or automated login. Connect the backend only to a Meta-authorized API/partner feed or another data source you have permission to collect and use.

## API contract
GET `/api/v1/listings?country=TH&sort=created_at_desc`

SSE GET `/api/v1/listings/stream?country=TH`

POST `/api/v1/listings` JSON example:
```json
{
  "id": "source-id",
  "title": "สินค้า",
  "price": 1500,
  "currency": "THB",
  "location": "กรุงเทพมหานคร",
  "created_at": "2026-09-07T16:55:00Z",
  "url": "https://...",
  "image_url": null,
  "source": "authorized-feed"
}
```

## Demo backend
`python3 backend/server.py`
Then run `python3 backend/push_sample.py` to inject a new listing; a connected app receives it live and puts it on top.

## Android emulator
Default backend URL is `http://10.0.2.2:8787` (host machine from Android emulator).
For a physical phone, enter the HTTPS URL or LAN IP of your backend.

## Build versions
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.3.21
- compileSdk 36 / targetSdk 36 / minSdk 26


## Android SDK build note
This V2 build uses Android 16 / API 36 (stable): `compileSdk = 36`, `targetSdk = 36`, and Build Tools `36.0.0`. This avoids requiring the Android 17 / API 37 preview SDK channel on GitHub Actions.
