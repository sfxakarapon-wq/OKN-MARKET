#!/usr/bin/env python3
"""Demo/adapter backend for MP Live TH V3.

This server DOES NOT scrape Facebook. Feed it only with data you are authorized
to collect/use. It exposes REST + SSE so the Android app can show newest first
and receive new items immediately.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
import json, threading, time, uuid, queue
from datetime import datetime, timezone

HOST = "0.0.0.0"
PORT = 8787
lock = threading.Lock()
subscribers = []

items = [
    {
        "id": "demo-3",
        "title": "ตัวอย่าง: ลำโพงมือสอง",
        "price": 2900,
        "currency": "THB",
        "location": "กรุงเทพมหานคร",
        "created_at": "2026-09-07T16:55:00Z",
        "url": "https://www.facebook.com/marketplace/",
        "image_url": None,
        "source": "demo"
    },
    {
        "id": "demo-2",
        "title": "ตัวอย่าง: เครื่องเสียงรถยนต์",
        "price": 4500,
        "currency": "THB",
        "location": "ขอนแก่น",
        "created_at": "2026-09-07T16:48:00Z",
        "url": "https://www.facebook.com/marketplace/",
        "image_url": None,
        "source": "demo"
    }
]


def sorted_items():
    with lock:
        return sorted(items, key=lambda x: x["created_at"], reverse=True)


def broadcast(item):
    payload = f"data: {json.dumps(item, ensure_ascii=False)}\n\n".encode("utf-8")
    dead = []
    with lock:
        for q in subscribers:
            try:
                q.put_nowait(payload)
            except Exception:
                dead.append(q)
        for q in dead:
            if q in subscribers:
                subscribers.remove(q)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print("[MP-LIVE]", fmt % args)

    def send_json(self, status, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/health":
            return self.send_json(200, {"ok": True, "service": "mp-live-th-v3"})
        if path == "/api/v1/listings":
            return self.send_json(200, sorted_items())
        if path == "/api/v1/listings/stream":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            event_queue = queue.Queue(maxsize=1000)
            with lock:
                subscribers.append(event_queue)
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
                while True:
                    try:
                        payload = event_queue.get(timeout=15)
                        self.wfile.write(payload)
                    except queue.Empty:
                        self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                with lock:
                    if event_queue in subscribers:
                        subscribers.remove(event_queue)
            return
        self.send_json(404, {"error": "not_found"})

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/api/v1/listings":
            return self.send_json(404, {"error": "not_found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            item = {
                "id": str(data.get("id") or uuid.uuid4()),
                "title": str(data["title"]),
                "price": float(data.get("price", 0)),
                "currency": str(data.get("currency", "THB")),
                "location": str(data.get("location", "Thailand")),
                "created_at": str(data.get("created_at") or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")),
                "url": str(data.get("url", "")),
                "image_url": data.get("image_url"),
                "source": str(data.get("source", "authorized-feed")),
            }
            with lock:
                items.append(item)
            broadcast(item)
            return self.send_json(201, item)
        except Exception as e:
            return self.send_json(400, {"error": str(e)})


if __name__ == "__main__":
    print(f"MP Live TH backend: http://127.0.0.1:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
