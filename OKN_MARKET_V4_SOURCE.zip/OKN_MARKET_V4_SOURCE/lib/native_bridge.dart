import 'dart:convert';

import 'package:flutter/services.dart';

import 'models.dart';

class NativeBridge {
  static const MethodChannel _channel =
      MethodChannel('com.okn.okn_market/native');

  static Future<List<FacebookEvent>> getFacebookEvents() async {
    final raw = await _channel.invokeMethod<String>('getImportedEvents');
    if (raw == null || raw.isEmpty) return <FacebookEvent>[];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .whereType<Map>()
          .map((item) => FacebookEvent.fromMap(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return <FacebookEvent>[];
    }
  }

  static Future<void> clearFacebookEvents() async {
    await _channel.invokeMethod<void>('clearImportedEvents');
  }

  static Future<void> openUrl(String url) async {
    await _channel.invokeMethod<void>('openUrl', {'url': url});
  }

  static Future<void> shareText(String text) async {
    await _channel.invokeMethod<void>('shareText', {'text': text});
  }
}
