package com.okn.okn_market

/**
 * V4 intentionally contains no NotificationListenerService.
 * The filename is kept only because the existing GitHub Actions workflow copies
 * this file into the generated Android project. No Android service is declared
 * in AndroidManifest.xml and no sensitive notification-listener permission is used.
 */
object MarketImportStore {
    const val PREFS_NAME = "okn_market_import_native"
    const val EVENTS_KEY = "facebook_shared_events"
    const val MAX_EVENTS = 200
}
