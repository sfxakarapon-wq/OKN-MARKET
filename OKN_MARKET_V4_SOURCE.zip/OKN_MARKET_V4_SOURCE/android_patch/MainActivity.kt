package com.okn.okn_market

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : FlutterActivity() {
    private val channelName = "com.okn.okn_market/native"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        importSharedText(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        importSharedText(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "getImportedEvents" -> result.success(readEvents())

                "clearImportedEvents" -> {
                    getSharedPreferences(MarketImportStore.PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(MarketImportStore.EVENTS_KEY, "[]")
                        .apply()
                    result.success(null)
                }

                "openUrl" -> {
                    val url = call.argument<String>("url")?.trim().orEmpty()
                    if (url.isBlank()) {
                        result.error("INVALID_URL", "URL is empty", null)
                    } else {
                        openUrl(url, result)
                    }
                }

                "shareText" -> {
                    val text = call.argument<String>("text").orEmpty()
                    shareText(text, result)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun importSharedText(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        if (incoming.type?.startsWith("text/") != true) return

        val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)
            ?.toString()
            ?.trim()
            .orEmpty()
        val subject = incoming.getStringExtra(Intent.EXTRA_SUBJECT)?.trim().orEmpty()

        if (text.isBlank() && subject.isBlank()) return

        val now = System.currentTimeMillis()
        val title = when {
            subject.isNotBlank() -> subject
            text.contains("marketplace", ignoreCase = true) -> "แชร์จาก Facebook Marketplace"
            text.contains("facebook.com/groups/", ignoreCase = true) -> "แชร์จากกลุ่ม Facebook"
            else -> "แชร์จาก Facebook"
        }

        val event = JSONObject().apply {
            put("id", "share_${now}_${text.hashCode()}")
            put("package", "android_share")
            put("title", title)
            put("text", text.ifBlank { subject })
            put("timestamp", now)
        }
        saveEvent(event)
    }

    private fun readEvents(): String {
        return getSharedPreferences(MarketImportStore.PREFS_NAME, MODE_PRIVATE)
            .getString(MarketImportStore.EVENTS_KEY, "[]") ?: "[]"
    }

    private fun saveEvent(event: JSONObject) {
        val prefs = getSharedPreferences(MarketImportStore.PREFS_NAME, MODE_PRIVATE)
        val current = try {
            JSONArray(prefs.getString(MarketImportStore.EVENTS_KEY, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

        val next = JSONArray()
        val newText = event.optString("text")
        next.put(event)

        var index = 0
        while (index < current.length() && next.length() < MarketImportStore.MAX_EVENTS) {
            val item = current.optJSONObject(index)
            if (item != null && item.optString("text") != newText) {
                next.put(item)
            }
            index++
        }

        prefs.edit().putString(MarketImportStore.EVENTS_KEY, next.toString()).apply()
    }

    private fun openUrl(url: String, result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            result.success(null)
        } catch (error: Exception) {
            result.error("OPEN_URL_ERROR", error.message, null)
        }
    }

    private fun shareText(text: String, result: MethodChannel.Result) {
        if (text.isBlank()) {
            result.error("EMPTY_TEXT", "Text is empty", null)
            return
        }

        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }

        try {
            val facebookIntent = Intent(baseIntent).apply {
                setPackage("com.facebook.katana")
            }
            startActivity(facebookIntent)
            result.success(null)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent.createChooser(baseIntent, "แชร์ข้อความขาย"))
                result.success(null)
            } catch (error: Exception) {
                result.error("SHARE_ERROR", error.message, null)
            }
        }
    }
}
