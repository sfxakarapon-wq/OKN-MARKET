OKN_MARKET V5 INSTALLABLE
=========================

เป้าหมายของ V5
- แก้ปัญหา APK ถูก Google Play Protect บล็อกตอน sideload บนมือถือ
- คง UI แบบ Facebook-inspired จาก V3
- คงระบบ Draft สินค้า, กลุ่ม, คิวโพสต์ และ Assisted Posting
- เปลี่ยน Monitor จาก Notification Access เป็น Android Share Import

สิ่งที่เปลี่ยนจาก V3
1) ลบ NotificationListenerService ออกจาก AndroidManifest.xml
2) ไม่ประกาศ android.permission.BIND_NOTIFICATION_LISTENER_SERVICE
3) ไม่เปิดหน้าขอ Notification Access
4) เพิ่ม Share Target สำหรับ text/plain
   Facebook / Marketplace / Group -> แชร์ -> OKN_MARKET
5) ข้อความหรือลิงก์ที่แชร์เข้ามาจะถูกเก็บสูงสุด 200 รายการ
6) Monitor ยังคงกรองด้วยคีย์เวิร์ดและแยก Marketplace / Group จากข้อความหรือลิงก์
7) Workflow เดิม build-okn-market.yml ใช้ต่อได้ โดยไม่ต้องแก้ไฟล์ workflow

วิธีใช้ Monitor V5
- เปิด Facebook
- เปิดโพสต์ Marketplace หรือโพสต์ในกลุ่มที่ต้องการ
- กด แชร์ (Share)
- เลือก OKN_MARKET จาก Android Share Sheet
- กลับเข้าเมนู Monitor
- รายการจะถูกเก็บและกรองตามคีย์เวิร์ดที่ตั้งไว้

หน้าจอหลัก
1) ภาพรวม
   - จำนวนโพสต์ที่นำเข้า
   - จำนวนที่ตรงคีย์เวิร์ด
   - จำนวนกลุ่มที่บันทึก
   - Draft ที่เตรียมไว้

2) Monitor
   - เพิ่ม/ลบคีย์เวิร์ด
   - Filter ทั้งหมด / Marketplace / Group
   - เก็บประวัติ Share Import สูงสุด 200 รายการ
   - รีเฟรชรายการอัตโนมัติขณะเปิดหน้า Monitor

3) ลงขาย
   - ชื่อสินค้า ราคา สภาพ รายละเอียด ติดต่อ
   - บันทึกร่าง
   - แชร์ข้อความขายไป Facebook

4) กลุ่ม
   - เพิ่ม/ลบชื่อและลิงก์กลุ่ม
   - คัดลอก Draft ก่อนเปิดกลุ่ม
   - ผู้ใช้กดโพสต์ขั้นสุดท้ายใน Facebook

ข้อจำกัด V5
- V5 ไม่อ่าน Notification ของ Facebook แบบอัตโนมัติ เพราะสิทธิ์ดังกล่าวเป็นสาเหตุที่ APK sideload ถูก Play Protect บล็อกในเครื่องที่ทดสอบ
- V5 ไม่ scrape Facebook และไม่ใช้ bot ล็อกอิน
- การนำข้อมูลเข้า Monitor ต้องกด Share จาก Facebook ไปยัง OKN_MARKET

Build
- ชื่อ source: OKN_MARKET_V5_SOURCE.zip
- ใช้ build-okn-market.yml เดิม
- workflow จะเลือกรุ่น V5 เป็นรุ่นล่าสุดและ build APK ให้อัตโนมัติ
