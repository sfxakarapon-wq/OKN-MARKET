package com.okn.okn_market

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : FlutterActivity() {
    private val channelName = "com.okn.okn_market/native"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        importSharedText(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        importSharedText(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "getImportedEvents" -> result.success(MarketImportStore.readEvents(this))

                "clearImportedEvents" -> {
                    MarketImportStore.clearEvents(this)
                    result.success(null)
                }

                "getLiveStatus" -> result.success(MarketImportStore.readLiveStatus(this))

                "openMarketplaceLive" -> {
                    val url = call.argument<String>("url")?.trim().orEmpty()
                    val intent = Intent(this, MarketplaceLiveActivity::class.java).apply {
                        putExtra(
                            MarketplaceLiveActivity.EXTRA_URL,
                            url.ifBlank { MarketplaceLiveActivity.DEFAULT_MARKETPLACE_URL }
                        )
                    }
                    startActivity(intent)
                    result.success(null)
                }

                "openUrl" -> {
                    val url = call.argument<String>("url")?.trim().orEmpty()
                    if (url.isBlank()) {
                        result.error("INVALID_URL", "URL is empty", null)
                    } else {
                        openUrl(url, result)
                    }
                }

                "shareText" -> {
                    val text = call.argument<String>("text").orEmpty()
                    shareText(text, result)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun importSharedText(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        if (incoming.type?.startsWith("text/") != true) return

        val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)
            ?.toString()
            ?.trim()
            .orEmpty()
        val subject = incoming.getStringExtra(Intent.EXTRA_SUBJECT)?.trim().orEmpty()

        if (text.isBlank() && subject.isBlank()) return

        val now = System.currentTimeMillis()
        val url = extractFirstUrl(text)
        val title = when {
            subject.isNotBlank() -> subject
            text.contains("marketplace", ignoreCase = true) -> "แชร์จาก Facebook Marketplace"
            text.contains("facebook.com/groups/", ignoreCase = true) -> "แชร์จากกลุ่ม Facebook"
            else -> "แชร์จาก Facebook"
        }

        val event = JSONObject().apply {
            put("id", "share_${now}_${text.hashCode()}")
            put("package", "android_share")
            put("title", title)
            put("text", text.ifBlank { subject })
            put("timestamp", now)
            put("url", url)
            put("imageUrl", "")
        }
        MarketImportStore.saveEvent(this, event)
    }

    private fun extractFirstUrl(text: String): String {
        val match = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(text)
        return match?.value?.trimEnd('.', ',', ')', ']', '}') ?: ""
    }

    private fun openUrl(url: String, result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            result.success(null)
        } catch (error: Exception) {
            result.error("OPEN_URL_ERROR", error.message, null)
        }
    }

    private fun shareText(text: String, result: MethodChannel.Result) {
        if (text.isBlank()) {
            result.error("EMPTY_TEXT", "Text is empty", null)
            return
        }

        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }

        try {
            val facebookIntent = Intent(baseIntent).apply {
                setPackage("com.facebook.katana")
            }
            startActivity(facebookIntent)
            result.success(null)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent.createChooser(baseIntent, "แชร์ข้อความขาย"))
                result.success(null)
            } catch (error: Exception) {
                result.error("SHARE_ERROR", error.message, null)
            }
        }
    }
}

class MarketplaceLiveActivity : Activity() {
    companion object {
        const val EXTRA_URL = "marketplace_url"
        const val DEFAULT_MARKETPLACE_URL = "https://www.facebook.com/marketplace/"
    }

    private lateinit var webView: WebView
    private lateinit var statusText: TextView
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val autoRefreshRunnable = object : Runnable {
        override fun run() {
            if (::webView.isInitialized && !isFinishing) {
                val currentUrl = webView.url.orEmpty()
                if (currentUrl.contains("facebook.com/marketplace/", ignoreCase = true)) {
                    webView.reload()
                }
                refreshHandler.postDelayed(this, 30_000L)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        val closeButton = Button(this).apply {
            text = "กลับ"
            isAllCaps = false
            setOnClickListener { finish() }
        }
        header.addView(closeButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))

        val titleWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
        }
        val title = TextView(this).apply {
            text = "OKN_MARKET • LIVE"
            textSize = 18f
            setTextColor(Color.rgb(24, 119, 242))
        }
        statusText = TextView(this).apply {
            text = "กำลังเปิด Marketplace • สแกน 5 วิ • รีเฟรช 30 วิ"
            textSize = 11f
            setTextColor(Color.DKGRAY)
        }
        titleWrap.addView(title)
        titleWrap.addView(statusText)
        header.addView(titleWrap, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val reloadButton = Button(this).apply {
            text = "รีเฟรช"
            isAllCaps = false
            setOnClickListener { webView.reload() }
        }
        header.addView(reloadButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))

        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(MarketplaceJsBridge(), "OKNBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectMarketplaceScanner()
            }
        }

        val startUrl = intent.getStringExtra(EXTRA_URL)?.trim().orEmpty().ifBlank {
            DEFAULT_MARKETPLACE_URL
        }
        webView.loadUrl(startUrl)
        refreshHandler.postDelayed(autoRefreshRunnable, 30_000L)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(autoRefreshRunnable)
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("OKNBridge")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun injectMarketplaceScanner() {
        val script = """
            (function() {
              if (window.__oknMarketLiveInstalled) {
                if (window.__oknMarketScanNow) window.__oknMarketScanNow();
                return;
              }
              window.__oknMarketLiveInstalled = true;

              function normalizeUrl(value) {
                try {
                  var u = new URL(value, location.origin);
                  u.hash = '';
                  var match = u.pathname.match(/\/marketplace\/item\/(\d+)/);
                  if (!match) return '';
                  return u.origin + '/marketplace/item/' + match[1] + '/';
                } catch (e) {
                  return '';
                }
              }

              function findCard(anchor) {
                var node = anchor;
                for (var i = 0; i < 8 && node; i++, node = node.parentElement) {
                  var text = (node.innerText || '').trim();
                  if (text.length >= 8 && text.length <= 2500) return node;
                }
                return anchor;
              }

              function scan() {
                try {
                  var anchors = Array.from(document.querySelectorAll('a[href*="/marketplace/item/"]'));
                  var seen = {};
                  var rows = [];
                  anchors.forEach(function(anchor) {
                    var url = normalizeUrl(anchor.href);
                    if (!url || seen[url]) return;
                    seen[url] = true;
                    var card = findCard(anchor);
                    var text = ((card && card.innerText) || anchor.innerText || '')
                      .replace(/\s+/g, ' ')
                      .trim();
                    var img = '';
                    try {
                      var image = card && card.querySelector ? card.querySelector('img') : null;
                      img = image ? (image.currentSrc || image.src || '') : '';
                    } catch (e) {}
                    rows.push({url: url, text: text.slice(0, 1400), image: img});
                  });
                  OKNBridge.onListings(JSON.stringify(rows.slice(0, 120)), location.href);
                } catch (e) {
                  try { OKNBridge.onScannerError(String(e)); } catch (_) {}
                }
              }

              window.__oknMarketScanNow = scan;
              scan();

              var timer = null;
              var observer = new MutationObserver(function() {
                clearTimeout(timer);
                timer = setTimeout(scan, 800);
              });
              observer.observe(document.documentElement || document.body, {childList: true, subtree: true});
              setInterval(scan, 5000);
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private inner class MarketplaceJsBridge {
        @JavascriptInterface
        fun onListings(payload: String, pageUrl: String) {
            try {
                val rows = JSONArray(payload)
                val now = System.currentTimeMillis()
                for (index in 0 until rows.length()) {
                    val row = rows.optJSONObject(index) ?: continue
                    val url = row.optString("url").trim()
                    if (url.isBlank()) continue
                    val text = row.optString("text").trim()
                    val imageUrl = row.optString("image").trim()
                    val title = buildTitle(text, url)

                    val event = JSONObject().apply {
                        put("id", "live_${url.hashCode()}")
                        put("package", "marketplace_webview")
                        put("title", title)
                        put("text", text.ifBlank { "พบประกาศ Marketplace ใหม่" })
                        put("timestamp", now)
                        put("url", url)
                        put("imageUrl", imageUrl)
                    }
                    MarketImportStore.saveEvent(this@MarketplaceLiveActivity, event)
                }

                MarketImportStore.recordLiveScan(this@MarketplaceLiveActivity, rows.length(), pageUrl)
                runOnUiThread {
                    statusText.text = "LIVE • พบ ${rows.length()} รายการ • สแกน 5 วิ • รีเฟรช 30 วิ"
                }
            } catch (error: Exception) {
                runOnUiThread {
                    statusText.text = "LIVE • รอข้อมูล Marketplace"
                }
            }
        }

        @JavascriptInterface
        fun onScannerError(message: String) {
            runOnUiThread {
                statusText.text = "LIVE • โหลดหน้าได้ แต่ยังอ่านรายการไม่ได้"
            }
        }
    }

    private fun buildTitle(text: String, url: String): String {
        val cleaned = text.replace(Regex("\\s+"), " ").trim()
        if (cleaned.isNotBlank()) {
            return if (cleaned.length > 90) cleaned.substring(0, 90) else cleaned
        }
        val id = Regex("/marketplace/item/(\\d+)").find(url)?.groupValues?.getOrNull(1)
        return if (id.isNullOrBlank()) "Facebook Marketplace" else "Marketplace #$id"
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
