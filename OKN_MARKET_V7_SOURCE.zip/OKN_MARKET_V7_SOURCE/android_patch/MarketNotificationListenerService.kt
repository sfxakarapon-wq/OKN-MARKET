package com.okn.okn_market

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Shared storage for Facebook Marketplace imports and the native Live monitor.
 *
 * NOTE: This file intentionally does NOT declare NotificationListenerService.
 * The filename is retained only because the existing GitHub Actions workflow
 * copies this exact filename into the generated Android project.
 */
object MarketImportStore {
    const val PREFS_NAME = "okn_market_import_native"
    const val EVENTS_KEY = "facebook_shared_events"
    const val STATUS_KEY = "marketplace_live_status"
    const val MAX_EVENTS = 300

    fun readEvents(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(EVENTS_KEY, "[]") ?: "[]"
    }

    fun clearEvents(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(EVENTS_KEY, "[]")
            .apply()
    }

    fun saveEvent(context: Context, event: JSONObject) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = try {
            JSONArray(prefs.getString(EVENTS_KEY, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

        val next = JSONArray()
        val newUrl = event.optString("url")
        val newText = event.optString("text")
        val newId = event.optString("id")

        var previousTimestamp = 0L
        var lookupIndex = 0
        while (lookupIndex < current.length()) {
            val item = current.optJSONObject(lookupIndex)
            if (item != null) {
                val sameId = newId.isNotBlank() && item.optString("id") == newId
                val sameUrl = newUrl.isNotBlank() && item.optString("url") == newUrl
                val sameText = newUrl.isBlank() && newText.isNotBlank() && item.optString("text") == newText
                if (sameId || sameUrl || sameText) {
                    previousTimestamp = item.optLong("timestamp", 0L)
                    break
                }
            }
            lookupIndex++
        }
        if (previousTimestamp > 0L) {
            event.put("timestamp", previousTimestamp)
        }
        next.put(event)

        var index = 0
        while (index < current.length() && next.length() < MAX_EVENTS) {
            val item = current.optJSONObject(index)
            if (item != null) {
                val sameId = newId.isNotBlank() && item.optString("id") == newId
                val sameUrl = newUrl.isNotBlank() && item.optString("url") == newUrl
                val sameText = newUrl.isBlank() && newText.isNotBlank() && item.optString("text") == newText
                if (!sameId && !sameUrl && !sameText) {
                    next.put(item)
                }
            }
            index++
        }

        prefs.edit().putString(EVENTS_KEY, next.toString()).apply()
    }

    fun recordLiveScan(context: Context, count: Int, pageUrl: String) {
        val status = JSONObject().apply {
            put("lastScan", System.currentTimeMillis())
            put("count", count)
            put("pageUrl", pageUrl)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(STATUS_KEY, status.toString())
            .apply()
    }

    fun readLiveStatus(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(STATUS_KEY, "{}") ?: "{}"
    }
}
