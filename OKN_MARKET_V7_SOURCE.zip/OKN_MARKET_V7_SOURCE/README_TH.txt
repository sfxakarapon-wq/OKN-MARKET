OKN_MARKET V7 REALTIME

วิธีใช้ Marketplace LIVE
1) เปิดแอป > Monitor
2) กด LIVE Marketplace
3) ถ้ายังไม่ล็อกอิน ให้ล็อกอิน Facebook ในหน้าต่าง LIVE
4) ตั้งพื้นที่ ราคา หมวด และคำค้นบน Marketplace ตามปกติ
5) เปิดหน้าผลการค้นหาค้างไว้ ระบบจะสแกนรายการที่มองเห็นทุกประมาณ 5 วินาที
6) กด กลับ เพื่อกลับ OKN_MARKET รายการที่พบจะอยู่ใน Monitor
7) แตะรายการเพื่อเปิดประกาศต้นฉบับ

หมายเหตุ
- V7 เป็น near-real-time จากหน้า Marketplace ที่ผู้ใช้เปิดอยู่ ไม่ใช่ Meta Marketplace public API
- ไม่ข้าม CAPTCHA/การยืนยันตัวตน และไม่พยายามหลบระบบป้องกันของ Facebook
- ถ้า Facebook เปลี่ยนโครงหน้า ตัวตรวจ DOM อาจต้องอัปเดต
- Share -> OKN_MARKET ยังคงใช้ได้เป็น fallback
