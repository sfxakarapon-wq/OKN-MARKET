package com.okn.mpliveth

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

private data class Listing(
    val id: String,
    val title: String,
    val price: Double,
    val currency: String,
    val location: String,
    val createdAt: Instant,
    val url: String,
    val imageUrl: String?,
    val source: String
)

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    private val running = AtomicBoolean(false)
    private val listings = mutableListOf<Listing>()

    private lateinit var adapter: ListingAdapter
    private lateinit var status: TextView
    private lateinit var endpoint: EditText
    private lateinit var connectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onDestroy() {
        running.set(false)
        io.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        val title = TextView(this).apply {
            text = "MP Live TH"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "รายการใหม่สุดต้องอยู่บนสุดเสมอ • Thailand"
            textSize = 14f
            setPadding(0, dp(2), 0, dp(10))
        }
        root.addView(subtitle)

        endpoint = EditText(this).apply {
            setText("http://10.0.2.2:8787")
            hint = "Backend URL"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        root.addView(endpoint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        connectButton = Button(this).apply {
            text = "CONNECT LIVE"
            setOnClickListener { toggleLive() }
        }
        val refreshButton = Button(this).apply {
            text = "REFRESH"
            setOnClickListener { fetchLatest() }
        }
        actions.addView(connectButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(refreshButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions)

        status = TextView(this).apply {
            text = "สถานะ: ยังไม่เชื่อมต่อ"
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        adapter = ListingAdapter(this, listings)
        val list = ListView(this).apply {
            dividerHeight = dp(1)
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, position, _ ->
                val item = listings[position]
                if (item.url.isNotBlank()) {
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(item.url)))
                }
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun toggleLive() {
        if (running.get()) {
            running.set(false)
            connectButton.text = "CONNECT LIVE"
            status.text = "สถานะ: หยุด Live"
            return
        }
        running.set(true)
        connectButton.text = "STOP LIVE"
        fetchLatest()
        startSseLoop()
    }

    private fun fetchLatest() {
        val base = endpoint.text.toString().trim().trimEnd('/')
        status.text = "สถานะ: กำลังโหลดรายการล่าสุด…"
        io.execute {
            try {
                val text = httpGet("$base/api/v1/listings?country=TH&sort=created_at_desc")
                val arr = JSONArray(text)
                val incoming = (0 until arr.length()).map { parseListing(arr.getJSONObject(it)) }
                main.post {
                    mergeListings(incoming)
                    status.text = "สถานะ: โหลดแล้ว ${listings.size} รายการ • ใหม่สุดอยู่บนสุด"
                }
            } catch (e: Exception) {
                main.post { status.text = "โหลดไม่ได้: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun startSseLoop() {
        val base = endpoint.text.toString().trim().trimEnd('/')
        io.execute {
            while (running.get()) {
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL("$base/api/v1/listings/stream?country=TH").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("Accept", "text/event-stream")
                        connectTimeout = 10_000
                        readTimeout = 0
                    }
                    conn.connect()
                    main.post { status.text = "สถานะ: LIVE • รอรายการใหม่…" }
                    BufferedReader(InputStreamReader(conn.inputStream)).use { reader ->
                        while (running.get()) {
                            val line = reader.readLine() ?: break
                            if (line.startsWith("data:")) {
                                val payload = line.removePrefix("data:").trim()
                                if (payload.isNotEmpty()) {
                                    val item = parseListing(JSONObject(payload))
                                    main.post {
                                        mergeListings(listOf(item))
                                        status.text = "LIVE • พบโพสต์ใหม่: ${item.title}"
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    if (running.get()) {
                        main.post { status.text = "LIVE หลุด • กำลังเชื่อมต่อใหม่…" }
                        Thread.sleep(2500)
                    }
                } finally {
                    conn?.disconnect()
                }
            }
        }
    }

    private fun mergeListings(incoming: List<Listing>) {
        val map = LinkedHashMap<String, Listing>()
        (incoming + listings).forEach { map[it.id] = it }
        listings.clear()
        listings.addAll(map.values.sortedByDescending { it.createdAt })
        adapter.notifyDataSetChanged()
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parseListing(o: JSONObject): Listing = Listing(
        id = o.getString("id"),
        title = o.optString("title", "Untitled"),
        price = o.optDouble("price", 0.0),
        currency = o.optString("currency", "THB"),
        location = o.optString("location", "Thailand"),
        createdAt = Instant.parse(o.getString("created_at")),
        url = o.optString("url", ""),
        imageUrl = o.optString("image_url", null),
        source = o.optString("source", "authorized-feed")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

private class ListingAdapter(
    private val context: Context,
    private val data: List<Listing>
) : BaseAdapter() {
    private val dtf = DateTimeFormatter.ofPattern("dd/MM HH:mm").withZone(ZoneId.of("Asia/Bangkok"))

    override fun getCount() = data.size
    override fun getItem(position: Int) = data[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val item = data[position]
        val box = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        box.removeAllViews()

        val isNew = Duration.between(item.createdAt, Instant.now()).toMinutes() in 0..10
        val top = TextView(context).apply {
            text = if (isNew) "ใหม่ • ${item.title}" else item.title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
        }
        val price = TextView(context).apply {
            text = if (item.price > 0) "${"%,.0f".format(item.price)} ${item.currency}" else "ไม่ระบุราคา"
            textSize = 16f
        }
        val meta = TextView(context).apply {
            text = "${item.location} • ${dtf.format(item.createdAt)} • ${item.source}"
            textSize = 12f
        }
        box.addView(top)
        box.addView(price)
        box.addView(meta)
        return box
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
