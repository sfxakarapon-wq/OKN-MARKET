#!/usr/bin/env python3
import json, urllib.request
from datetime import datetime, timezone

payload = {
    "title": "ตัวอย่างโพสต์ใหม่แบบ Real-time",
    "price": 990,
    "currency": "THB",
    "location": "มหาสารคาม",
    "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "url": "https://www.facebook.com/marketplace/",
    "source": "authorized-feed"
}
req = urllib.request.Request(
    "http://127.0.0.1:8787/api/v1/listings",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST"
)
print(urllib.request.urlopen(req).read().decode())
