class FacebookEvent {
  final String id;
  final String packageName;
  final String title;
  final String text;
  final int timestamp;

  const FacebookEvent({
    required this.id,
    required this.packageName,
    required this.title,
    required this.text,
    required this.timestamp,
  });

  factory FacebookEvent.fromMap(Map<String, dynamic> map) {
    return FacebookEvent(
      id: map['id']?.toString() ?? '',
      packageName: map['package']?.toString() ?? '',
      title: map['title']?.toString() ?? '',
      text: map['text']?.toString() ?? '',
      timestamp: (map['timestamp'] as num?)?.toInt() ?? 0,
    );
  }

  String get searchable => '$title $text'.toLowerCase();
}

class GroupTarget {
  final String name;
  final String url;

  const GroupTarget({required this.name, required this.url});

  factory GroupTarget.fromMap(Map<String, dynamic> map) {
    return GroupTarget(
      name: map['name']?.toString() ?? '',
      url: map['url']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toMap() => {'name': name, 'url': url};
}

class SaleDraft {
  final String title;
  final String price;
  final String details;
  final String contact;

  const SaleDraft({
    this.title = '',
    this.price = '',
    this.details = '',
    this.contact = '',
  });

  factory SaleDraft.fromMap(Map<String, dynamic> map) {
    return SaleDraft(
      title: map['title']?.toString() ?? '',
      price: map['price']?.toString() ?? '',
      details: map['details']?.toString() ?? '',
      contact: map['contact']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'price': price,
        'details': details,
        'contact': contact,
      };

  String composePost() {
    final lines = <String>[];
    if (title.trim().isNotEmpty) lines.add(title.trim());
    if (price.trim().isNotEmpty) lines.add('ราคา ${price.trim()}');
    if (details.trim().isNotEmpty) {
      lines.add('');
      lines.add(details.trim());
    }
    if (contact.trim().isNotEmpty) {
      lines.add('');
      lines.add('ติดต่อ: ${contact.trim()}');
    }
    return lines.join('\n');
  }
}
