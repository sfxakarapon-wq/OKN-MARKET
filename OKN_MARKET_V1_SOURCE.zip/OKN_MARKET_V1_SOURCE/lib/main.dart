import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models.dart';
import 'native_bridge.dart';
import 'storage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OknMarketApp());
}

class OknMarketApp extends StatelessWidget {
  const OknMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN Market',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const DashboardScreen(),
      const MonitorScreen(),
      const SaleDraftScreen(),
      const GroupsScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('OKN Market V1'),
        centerTitle: false,
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'ภาพรวม',
          ),
          NavigationDestination(
            icon: Icon(Icons.notifications_active_outlined),
            selectedIcon: Icon(Icons.notifications_active),
            label: 'Monitor',
          ),
          NavigationDestination(
            icon: Icon(Icons.sell_outlined),
            selectedIcon: Icon(Icons.sell),
            label: 'ลงขาย',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups),
            label: 'กลุ่ม',
          ),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _accessEnabled = false;
  int _eventCount = 0;
  int _groupCount = 0;
  String _draftTitle = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final access = await NativeBridge.notificationAccessEnabled();
    final events = await NativeBridge.getFacebookEvents();
    final groups = await AppStorage.loadGroups();
    final draft = await AppStorage.loadDraft();
    if (!mounted) return;
    setState(() {
      _accessEnabled = access;
      _eventCount = events.length;
      _groupCount = groups.length;
      _draftTitle = draft.title;
    });
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _StatusBanner(enabled: _accessEnabled),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              _MetricCard(
                icon: Icons.notifications,
                label: 'เหตุการณ์ Facebook',
                value: '$_eventCount',
              ),
              _MetricCard(
                icon: Icons.groups,
                label: 'กลุ่มที่บันทึก',
                value: '$_groupCount',
              ),
              _MetricCard(
                icon: Icons.sell,
                label: 'Draft สินค้า',
                value: _draftTitle.trim().isEmpty ? 'ยังไม่มี' : 'พร้อม',
              ),
            ],
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('สถานะ V1', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 10),
                  const _FeatureRow(
                    icon: Icons.check_circle,
                    text: 'อ่าน Notification จากแอป Facebook ที่ผู้ใช้อนุญาต',
                  ),
                  const _FeatureRow(
                    icon: Icons.check_circle,
                    text: 'กรองด้วยคำค้น และเก็บประวัติสูงสุด 200 รายการ',
                  ),
                  const _FeatureRow(
                    icon: Icons.check_circle,
                    text: 'สร้างข้อความขายและเก็บ Draft ในเครื่อง',
                  ),
                  const _FeatureRow(
                    icon: Icons.check_circle,
                    text: 'บันทึกลิงก์กลุ่ม + คัดลอกข้อความ + เปิดกลุ่มเพื่อโพสต์',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _refresh,
            icon: const Icon(Icons.refresh),
            label: const Text('รีเฟรชสถานะ'),
          ),
        ],
      ),
    );
  }
}

class MonitorScreen extends StatefulWidget {
  const MonitorScreen({super.key});

  @override
  State<MonitorScreen> createState() => _MonitorScreenState();
}

class _MonitorScreenState extends State<MonitorScreen>
    with WidgetsBindingObserver {
  Timer? _timer;
  bool _accessEnabled = false;
  bool _loading = true;
  List<FacebookEvent> _events = <FacebookEvent>[];
  List<String> _keywords = <String>[];
  final TextEditingController _keywordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refreshEvents());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _keywordController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _loadAll();
  }

  Future<void> _loadAll() async {
    final access = await NativeBridge.notificationAccessEnabled();
    final keywords = await AppStorage.loadKeywords();
    final events = await NativeBridge.getFacebookEvents();
    if (!mounted) return;
    setState(() {
      _accessEnabled = access;
      _keywords = keywords;
      _events = events;
      _loading = false;
    });
  }

  Future<void> _refreshEvents() async {
    final events = await NativeBridge.getFacebookEvents();
    if (!mounted) return;
    setState(() => _events = events);
  }

  Future<void> _addKeyword() async {
    final value = _keywordController.text.trim().toLowerCase();
    if (value.isEmpty || _keywords.contains(value)) return;
    final next = [..._keywords, value];
    await AppStorage.saveKeywords(next);
    if (!mounted) return;
    setState(() {
      _keywords = next;
      _keywordController.clear();
    });
  }

  Future<void> _removeKeyword(String keyword) async {
    final next = _keywords.where((item) => item != keyword).toList();
    await AppStorage.saveKeywords(next);
    if (!mounted) return;
    setState(() => _keywords = next);
  }

  Future<void> _clear() async {
    await NativeBridge.clearFacebookEvents();
    await _refreshEvents();
  }

  List<FacebookEvent> get _filteredEvents {
    if (_keywords.isEmpty) return _events;
    return _events.where((event) {
      return _keywords.any((keyword) => event.searchable.contains(keyword));
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    final filtered = _filteredEvents;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _StatusBanner(enabled: _accessEnabled),
        if (!_accessEnabled) ...[
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: NativeBridge.openNotificationSettings,
            icon: const Icon(Icons.settings),
            label: const Text('เปิดหน้าตั้งค่าสิทธิ์ Notification Access'),
          ),
        ],
        const SizedBox(height: 16),
        Text('คำค้น', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _keywords
              .map(
                (keyword) => InputChip(
                  label: Text(keyword),
                  onDeleted: () => _removeKeyword(keyword),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _keywordController,
                decoration: const InputDecoration(
                  labelText: 'เพิ่มคำค้น เช่น dsp / subwoofer',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _addKeyword(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: _addKeyword,
              icon: const Icon(Icons.add),
              tooltip: 'เพิ่มคำค้น',
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: Text(
                'พบ ${filtered.length} รายการที่ตรงคำค้น',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            TextButton.icon(
              onPressed: _events.isEmpty ? null : _clear,
              icon: const Icon(Icons.delete_outline),
              label: const Text('ล้าง'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (filtered.isEmpty)
          const _EmptyCard(
            icon: Icons.notifications_none,
            title: 'ยังไม่มีรายการที่ตรงคำค้น',
            subtitle:
                'เมื่อ Facebook ส่ง Notification ใหม่ แอปจะรับและแสดงที่นี่โดยอัตโนมัติ',
          )
        else
          ...filtered.map((event) => _EventCard(event: event)),
      ],
    );
  }
}

class SaleDraftScreen extends StatefulWidget {
  const SaleDraftScreen({super.key});

  @override
  State<SaleDraftScreen> createState() => _SaleDraftScreenState();
}

class _SaleDraftScreenState extends State<SaleDraftScreen> {
  final _titleController = TextEditingController();
  final _priceController = TextEditingController();
  final _detailsController = TextEditingController();
  final _contactController = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final draft = await AppStorage.loadDraft();
    _titleController.text = draft.title;
    _priceController.text = draft.price;
    _detailsController.text = draft.details;
    _contactController.text = draft.contact;
    if (!mounted) return;
    setState(() => _loaded = true);
  }

  SaleDraft _currentDraft() => SaleDraft(
        title: _titleController.text,
        price: _priceController.text,
        details: _detailsController.text,
        contact: _contactController.text,
      );

  Future<void> _save() async {
    await AppStorage.saveDraft(_currentDraft());
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('บันทึก Draft แล้ว')),
    );
  }

  Future<void> _share() async {
    final draft = _currentDraft();
    final text = draft.composePost();
    if (text.trim().isEmpty) return;
    await AppStorage.saveDraft(draft);
    await NativeBridge.shareText(text);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _priceController.dispose();
    _detailsController.dispose();
    _contactController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('สร้างข้อความขาย', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        TextField(
          controller: _titleController,
          decoration: const InputDecoration(
            labelText: 'ชื่อสินค้า',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _priceController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'ราคา',
            suffixText: 'บาท',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _detailsController,
          maxLines: 6,
          decoration: const InputDecoration(
            labelText: 'รายละเอียดสินค้า',
            alignLabelWithHint: true,
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _contactController,
          decoration: const InputDecoration(
            labelText: 'ช่องทางติดต่อ',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save_outlined),
                label: const Text('บันทึก Draft'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: _share,
                icon: const Icon(Icons.share),
                label: const Text('แชร์ข้อความ'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Text(
          'หมายเหตุ: V1 ช่วยเตรียมและแชร์ข้อความ แต่ไม่กดโพสต์แทนผู้ใช้ใน Facebook',
        ),
      ],
    );
  }
}

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  List<GroupTarget> _groups = <GroupTarget>[];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final groups = await AppStorage.loadGroups();
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _loading = false;
    });
  }

  Future<void> _addGroup() async {
    final nameController = TextEditingController();
    final urlController = TextEditingController(text: 'https://www.facebook.com/groups/');
    final result = await showDialog<GroupTarget>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('เพิ่มกลุ่ม Facebook'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'ชื่อกลุ่ม'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: urlController,
              decoration: const InputDecoration(labelText: 'ลิงก์กลุ่ม'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('ยกเลิก'),
          ),
          FilledButton(
            onPressed: () {
              final name = nameController.text.trim();
              final url = urlController.text.trim();
              if (name.isEmpty || !url.startsWith('http')) return;
              Navigator.pop(context, GroupTarget(name: name, url: url));
            },
            child: const Text('เพิ่ม'),
          ),
        ],
      ),
    );
    nameController.dispose();
    urlController.dispose();
    if (result == null) return;
    final next = [..._groups, result];
    await AppStorage.saveGroups(next);
    if (!mounted) return;
    setState(() => _groups = next);
  }

  Future<void> _deleteGroup(int index) async {
    final next = [..._groups]..removeAt(index);
    await AppStorage.saveGroups(next);
    if (!mounted) return;
    setState(() => _groups = next);
  }

  Future<void> _openForPosting(GroupTarget group) async {
    final draft = await AppStorage.loadDraft();
    final post = draft.composePost();
    if (post.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('กรุณาสร้าง Draft สินค้าก่อน')),
      );
      return;
    }
    await Clipboard.setData(ClipboardData(text: post));
    await NativeBridge.openUrl(group.url);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('คัดลอกข้อความแล้ว เปิดกลุ่มเพื่อวางและโพสต์ได้เลย')),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(
              child: Text('กลุ่มสำหรับลงขาย',
                  style: Theme.of(context).textTheme.titleLarge),
            ),
            FilledButton.icon(
              onPressed: _addGroup,
              icon: const Icon(Icons.add),
              label: const Text('เพิ่มกลุ่ม'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_groups.isEmpty)
          const _EmptyCard(
            icon: Icons.groups_outlined,
            title: 'ยังไม่ได้เพิ่มกลุ่ม',
            subtitle: 'เพิ่มชื่อและลิงก์กลุ่ม Facebook ที่คุณเป็นสมาชิก',
          )
        else
          ..._groups.asMap().entries.map((entry) {
            final index = entry.key;
            final group = entry.value;
            return Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.groups)),
                title: Text(group.name),
                subtitle: Text(
                  group.url,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'delete') _deleteGroup(index);
                  },
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'delete', child: Text('ลบกลุ่ม')),
                  ],
                ),
                onTap: () => _openForPosting(group),
              ),
            );
          }),
        if (_groups.isNotEmpty) ...[
          const SizedBox(height: 8),
          const Text(
            'แตะชื่อกลุ่ม: แอปจะคัดลอก Draft ล่าสุด แล้วเปิดกลุ่ม Facebook ให้คุณวางข้อความและกดโพสต์',
          ),
        ],
      ],
    );
  }
}

class _StatusBanner extends StatelessWidget {
  final bool enabled;

  const _StatusBanner({required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(
          enabled ? Icons.verified_user : Icons.warning_amber_rounded,
        ),
        title: Text(enabled ? 'Notification Access เปิดอยู่' : 'ยังไม่ได้เปิด Notification Access'),
        subtitle: Text(
          enabled
              ? 'OKN Market พร้อมรับ Notification จาก Facebook'
              : 'ต้องเปิดสิทธิ์นี้ก่อนจึงจะใช้ Group / Marketplace Monitor ได้',
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _MetricCard({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 165,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon),
              const SizedBox(height: 12),
              Text(value, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 4),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _FeatureRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Icon(icon, size: 44),
            const SizedBox(height: 10),
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(subtitle, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _EventCard extends StatelessWidget {
  final FacebookEvent event;

  const _EventCard({required this.event});

  String _formatTime(int millis) {
    if (millis <= 0) return '-';
    final date = DateTime.fromMillisecondsSinceEpoch(millis).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(date.day)}/${two(date.month)}/${date.year} ${two(date.hour)}:${two(date.minute)}:${two(date.second)}';
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.public),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    event.title.isEmpty ? 'Facebook' : event.title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
              ],
            ),
            if (event.text.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(event.text),
            ],
            const SizedBox(height: 10),
            Text(
              _formatTime(event.timestamp),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
