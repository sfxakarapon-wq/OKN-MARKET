OKN MARKET V1
==============

สถานะ: MVP สำหรับ Android
Package: com.okn.okn_market
Version: 1.0.0+1

สิ่งที่มีใน V1
- Dashboard แสดงสถานะ Notification Access / จำนวนเหตุการณ์ / จำนวนกลุ่ม / Draft
- Android NotificationListenerService รับ Notification จาก Facebook, Facebook Lite และ Messenger
- เก็บเหตุการณ์ล่าสุดสูงสุด 200 รายการในเครื่อง
- Monitor กรองเหตุการณ์ด้วยคำค้นที่ผู้ใช้เพิ่ม/ลบได้
- สร้าง Draft ขายสินค้า: ชื่อ ราคา รายละเอียด ช่องทางติดต่อ
- เก็บรายชื่อและลิงก์ Facebook Group
- แตะกลุ่มเพื่อคัดลอกข้อความขาย แล้วเปิดลิงก์กลุ่มให้ผู้ใช้วางและกดโพสต์เอง
- แชร์ข้อความขายผ่าน Android Share Sheet / Facebook App

ข้อจำกัดที่ตั้งใจไว้
- ไม่เก็บรหัสผ่าน Facebook
- ไม่ล็อกอิน Facebook แทนผู้ใช้
- ไม่ scrape หน้า Facebook/Marketplace
- ไม่กดโพสต์อัตโนมัติแทนผู้ใช้
- Monitor เห็นเฉพาะข้อมูลที่ Facebook ส่งมาเป็น Android Notification

ไฟล์สำคัญ
- lib/main.dart : UI และ flow หลัก
- lib/native_bridge.dart : Flutter <-> Android bridge
- android_patch/MarketNotificationListenerService.kt : รับ Notification แบบ native
- android_patch/MainActivity.kt : เปิด settings / URL / share และอ่าน event store
- android_patch/AndroidManifest.xml : ประกาศ Notification Listener Service

Build
ใช้ไฟล์ build-okn-market.yml แยกต่างหากใน .github/workflows/
Workflow ถูกออกแบบให้จับไฟล์ OKN_MARKET_V*_SOURCE.zip อัตโนมัติ และ build APK รุ่นล่าสุด
