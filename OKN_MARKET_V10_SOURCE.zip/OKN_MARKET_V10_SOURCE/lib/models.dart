class FacebookEvent {
  final String id;
  final String packageName;
  final String title;
  final String text;
  final int timestamp;
  final String url;
  final String imageUrl;
  final String marketCountry;

  const FacebookEvent({
    required this.id,
    required this.packageName,
    required this.title,
    required this.text,
    required this.timestamp,
    this.url = '',
    this.imageUrl = '',
    this.marketCountry = '',
  });

  factory FacebookEvent.fromMap(Map<String, dynamic> map) {
    return FacebookEvent(
      id: map['id']?.toString() ?? '',
      packageName: map['package']?.toString() ?? '',
      title: map['title']?.toString() ?? '',
      text: map['text']?.toString() ?? '',
      timestamp: (map['timestamp'] as num?)?.toInt() ?? 0,
      url: map['url']?.toString() ?? '',
      imageUrl: map['imageUrl']?.toString() ?? '',
      marketCountry: map['marketCountry']?.toString() ?? '',
    );
  }

  String get searchable => '$title $text $url'.toLowerCase();

  bool get isThailand {
    if (marketCountry.toUpperCase() == 'TH') return true;
    final value = '$title $text'.toLowerCase();
    const thaiHints = <String>[
      'ประเทศไทย', 'thailand', 'กรุงเทพ', 'bangkok', 'นนทบุรี', 'ปทุมธานี',
      'สมุทรปราการ', 'ชลบุรี', 'เชียงใหม่', 'เชียงราย', 'ขอนแก่น', 'นครราชสีมา',
      'โคราช', 'ภูเก็ต', 'สงขลา', 'หาดใหญ่', 'อุดรธานี', 'ระยอง', 'บาท', '฿'
    ];
    return thaiHints.any(value.contains);
  }

  String get sourceLabel {
    final value = searchable;
    if (packageName == 'marketplace_webview') return 'Marketplace';
    if (value.contains('marketplace') || value.contains('/marketplace/')) {
      return 'Marketplace';
    }
    if (value.contains('facebook.com/groups/') ||
        value.contains('group') ||
        value.contains('กลุ่ม')) {
      return 'Group';
    }
    return 'Facebook';
  }
}

class GroupTarget {
  final String name;
  final String url;

  const GroupTarget({required this.name, required this.url});

  factory GroupTarget.fromMap(Map<String, dynamic> map) {
    return GroupTarget(
      name: map['name']?.toString() ?? '',
      url: map['url']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toMap() => {'name': name, 'url': url};
}

class SaleDraft {
  final String title;
  final String price;
  final String condition;
  final String details;
  final String contact;
  final String contactMethod;

  const SaleDraft({
    this.title = '',
    this.price = '',
    this.condition = 'มือสอง',
    this.details = '',
    this.contact = '',
    this.contactMethod = 'Messenger (Facebook)',
  });

  factory SaleDraft.fromMap(Map<String, dynamic> map) {
    return SaleDraft(
      title: map['title']?.toString() ?? '',
      price: map['price']?.toString() ?? '',
      condition: map['condition']?.toString() ?? 'มือสอง',
      details: map['details']?.toString() ?? '',
      contact: map['contact']?.toString() ?? '',
      contactMethod:
          map['contactMethod']?.toString() ?? 'Messenger (Facebook)',
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'price': price,
        'condition': condition,
        'details': details,
        'contact': contact,
        'contactMethod': contactMethod,
      };

  String composePost() {
    final lines = <String>[];
    if (title.trim().isNotEmpty) lines.add('📦 ${title.trim()}');
    if (price.trim().isNotEmpty) lines.add('💰 ราคา ${price.trim()} บาท');
    if (condition.trim().isNotEmpty) lines.add('✅ สภาพ: ${condition.trim()}');
    if (details.trim().isNotEmpty) {
      lines.add('');
      lines.add(details.trim());
    }
    if (contactMethod.trim().isNotEmpty || contact.trim().isNotEmpty) {
      lines.add('');
      final detail = contact.trim().isEmpty ? contactMethod : '$contactMethod: ${contact.trim()}';
      lines.add('📩 ติดต่อ: $detail');
    }
    return lines.join('\n');
  }
}
