OKN_MARKET V10 AUTO LIVE

การทำงาน
1) เปิด OKN_MARKET แล้ว AUTO LIVE จะเริ่มเองทันที ไม่ต้องกดรีเฟรช
2) หน้าแรกจะอัปเดต Feed เองทุกประมาณ 2 วินาทีจากข้อมูลที่ตัวสแกนพบ
3) ตัวสแกน Marketplace ตรวจหน้าโดยประมาณทุก 5 วินาที
4) รายการที่ระบุ TH / บาท / จังหวัดหรือพื้นที่ในไทย จะถูกจัดขึ้นก่อนเสมอ
5) ถ้ายังไม่เคยล็อกอิน Facebook ใน WebView ให้กด LIVE/ล็อกอินเพียงครั้งแรก จากนั้น session จะถูกใช้ต่ออัตโนมัติ

ข้อจำกัด
- เป็น near-real-time จากหน้า Facebook Marketplace ใน WebView ไม่ใช่ Meta Marketplace public API
- AUTO LIVE ถูกออกแบบให้ทำงานขณะ OKN_MARKET เปิดอยู่; Android อาจพักการทำงานเมื่อแอปถูกส่งไปเบื้องหลัง
- ไม่ข้าม CAPTCHA/2FA/การยืนยันตัวตน และไม่หลบระบบป้องกันของ Facebook
- ถ้า Facebook เปลี่ยน DOM ตัว scanner อาจต้องอัปเดต
