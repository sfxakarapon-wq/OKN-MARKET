import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class AppStorage {
  static const _keywordsKey = 'monitor_keywords';
  static const _groupsKey = 'group_targets';
  static const _draftKey = 'sale_draft';

  static Future<List<String>> loadKeywords() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_keywordsKey) ??
        const ['dsp', 'เครื่องเสียง', 'แอมป์', 'ลำโพง'];
  }

  static Future<void> saveKeywords(List<String> keywords) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_keywordsKey, keywords);
  }

  static Future<List<GroupTarget>> loadGroups() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_groupsKey);
    if (raw == null || raw.isEmpty) return <GroupTarget>[];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .whereType<Map>()
          .map((item) => GroupTarget.fromMap(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return <GroupTarget>[];
    }
  }

  static Future<void> saveGroups(List<GroupTarget> groups) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(groups.map((group) => group.toMap()).toList());
    await prefs.setString(_groupsKey, raw);
  }

  static Future<SaleDraft> loadDraft() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_draftKey);
    if (raw == null || raw.isEmpty) return const SaleDraft();
    try {
      return SaleDraft.fromMap(
        Map<String, dynamic>.from(jsonDecode(raw) as Map),
      );
    } catch (_) {
      return const SaleDraft();
    }
  }

  static Future<void> saveDraft(SaleDraft draft) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_draftKey, jsonEncode(draft.toMap()));
  }
}
