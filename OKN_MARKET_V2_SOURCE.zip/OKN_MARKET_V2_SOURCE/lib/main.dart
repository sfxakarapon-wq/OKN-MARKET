import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models.dart';
import 'native_bridge.dart';
import 'storage.dart';

const Color kFacebookBlue = Color(0xFF1877F2);
const Color kAppBackground = Color(0xFFF0F2F5);
const Color kTextPrimary = Color(0xFF17223B);
const Color kTextSecondary = Color(0xFF667085);
const Color kBorder = Color(0xFFE4E7EC);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const OknMarketApp());
}

class OknMarketApp extends StatelessWidget {
  const OknMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: kFacebookBlue,
      brightness: Brightness.light,
      surface: Colors.white,
    );

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'OKN_MARKET',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: kAppBackground,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: kTextPrimary,
          elevation: 0,
          surfaceTintColor: Colors.transparent,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFFF0F1F3)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kFacebookBlue, width: 1.5),
          ),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      DashboardScreen(onOpenTab: (index) => setState(() => _index = index)),
      const MonitorScreen(),
      const SaleDraftScreen(),
      const GroupsScreen(),
    ];

    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: _FacebookBottomNav(
        selectedIndex: _index,
        onSelected: (index) => setState(() => _index = index),
      ),
    );
  }
}

class _FacebookBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  const _FacebookBottomNav({
    required this.selectedIndex,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    const items = <_NavItem>[
      _NavItem(Icons.home_outlined, Icons.home, 'ภาพรวม'),
      _NavItem(Icons.search, Icons.search, 'Monitor'),
      _NavItem(Icons.add_circle_outline, Icons.add_circle, 'ลงขาย'),
      _NavItem(Icons.groups_outlined, Icons.groups, 'กลุ่ม'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: kBorder)),
      ),
      padding: const EdgeInsets.only(top: 6, bottom: 4),
      child: Row(
        children: List.generate(items.length, (index) {
          final item = items[index];
          final selected = index == selectedIndex;
          return Expanded(
            child: InkWell(
              onTap: () => onSelected(index),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      selected ? item.selectedIcon : item.icon,
                      color: selected ? kFacebookBlue : const Color(0xFF51647E),
                      size: index == 2 ? 31 : 26,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      item.label,
                      style: TextStyle(
                        color: selected ? kFacebookBlue : const Color(0xFF51647E),
                        fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const _NavItem(this.icon, this.selectedIcon, this.label);
}

class _PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget? trailing;
  final bool brand;

  const _PageHeader({
    required this.title,
    required this.subtitle,
    this.trailing,
    this.brand = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      child: Row(
        children: [
          if (brand) ...[
            const CircleAvatar(
              radius: 18,
              backgroundColor: kFacebookBlue,
              child: Icon(Icons.notifications_active, color: Colors.white, size: 19),
            ),
            const SizedBox(width: 10),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: brand ? kFacebookBlue : kTextPrimary,
                    fontSize: brand ? 20 : 22,
                    fontWeight: FontWeight.w800,
                    height: 1.1,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: kTextSecondary,
                    fontSize: 12,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  final ValueChanged<int> onOpenTab;

  const DashboardScreen({super.key, required this.onOpenTab});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _accessEnabled = false;
  int _eventCount = 0;
  int _matchedCount = 0;
  int _groupCount = 0;
  bool _hasDraft = false;
  List<FacebookEvent> _events = const [];
  List<String> _keywords = const [];

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final access = await NativeBridge.notificationAccessEnabled();
    final events = await NativeBridge.getFacebookEvents();
    final groups = await AppStorage.loadGroups();
    final draft = await AppStorage.loadDraft();
    final keywords = await AppStorage.loadKeywords();
    final matched = keywords.isEmpty
        ? events.length
        : events.where((e) => keywords.any((k) => e.searchable.contains(k))).length;

    if (!mounted) return;
    setState(() {
      _accessEnabled = access;
      _events = events;
      _eventCount = events.length;
      _matchedCount = matched;
      _groupCount = groups.length;
      _hasDraft = draft.title.trim().isNotEmpty;
      _keywords = keywords;
    });
  }

  @override
  Widget build(BuildContext context) {
    final recent = _events.take(5).toList();
    return Column(
      children: [
        _PageHeader(
          title: 'OKN_MARKET',
          subtitle: 'ติดตามโอกาสดีๆ ได้ก่อนใคร',
          brand: true,
          trailing: IconButton(
            onPressed: () => widget.onOpenTab(1),
            icon: const Icon(Icons.notifications, color: kFacebookBlue),
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 20),
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'ภาพรวม',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                      ),
                    ),
                    Text(
                      _accessEnabled ? 'Monitor พร้อมใช้งาน' : 'ต้องเปิดสิทธิ์ Monitor',
                      style: TextStyle(
                        color: _accessEnabled ? const Color(0xFF14804A) : const Color(0xFFC4320A),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.55,
                  children: [
                    _MetricTile(
                      icon: Icons.notifications,
                      title: 'แจ้งเตือนใหม่วันนี้',
                      value: '$_eventCount',
                      suffix: 'รายการ',
                      tint: const Color(0xFFEAF3FF),
                      accent: kFacebookBlue,
                    ),
                    _MetricTile(
                      icon: Icons.search,
                      title: 'รายการที่ตรงคำค้น',
                      value: '$_matchedCount',
                      suffix: 'รายการ',
                      tint: const Color(0xFFECFDF3),
                      accent: const Color(0xFF16834B),
                    ),
                    _MetricTile(
                      icon: Icons.groups,
                      title: 'โพสต์ในกลุ่มที่รอ',
                      value: '$_groupCount',
                      suffix: 'รายการ',
                      tint: const Color(0xFFF4F0FF),
                      accent: const Color(0xFF6938EF),
                    ),
                    _MetricTile(
                      icon: Icons.description,
                      title: 'โพสต์ที่เตรียมไว้',
                      value: _hasDraft ? '1' : '0',
                      suffix: 'รายการ',
                      tint: const Color(0xFFFFF3E8),
                      accent: const Color(0xFFE56A00),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                _SectionTitle(
                  title: 'สินค้าที่พบล่าสุด',
                  actionText: 'ดูทั้งหมด',
                  onTap: () => widget.onOpenTab(1),
                ),
                const SizedBox(height: 8),
                if (recent.isEmpty)
                  _EmptyFacebookCard(
                    icon: Icons.search,
                    title: 'ยังไม่มีรายการที่ตรวจพบ',
                    subtitle: _accessEnabled
                        ? 'เมื่อ Facebook ส่ง Notification ที่ตรงคำค้น รายการจะขึ้นตรงนี้ทันที'
                        : 'เปิด Notification Access ก่อน เพื่อเริ่มรับข้อมูลจาก Facebook',
                  )
                else
                  Card(
                    child: Column(
                      children: List.generate(recent.length, (index) {
                        final event = recent[index];
                        return Column(
                          children: [
                            _CompactEventRow(event: event, keywords: _keywords),
                            if (index != recent.length - 1)
                              const Divider(height: 1, indent: 82),
                          ],
                        );
                      }),
                    ),
                  ),
                const SizedBox(height: 16),
                if (!_accessEnabled)
                  FilledButton.icon(
                    onPressed: NativeBridge.openNotificationSettings,
                    icon: const Icon(Icons.settings),
                    label: const Text('เปิด Notification Access'),
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}


class _MetricTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final String suffix;
  final Color tint;
  final Color accent;

  const _MetricTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.suffix,
    required this.tint,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: tint,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, color: accent, size: 22),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  title,
                  maxLines: 2,
                  style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: TextStyle(color: accent, fontSize: 28, fontWeight: FontWeight.w900, height: 1),
              ),
              const SizedBox(width: 5),
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(suffix, style: TextStyle(color: accent, fontSize: 11)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class MonitorScreen extends StatefulWidget {
  const MonitorScreen({super.key});

  @override
  State<MonitorScreen> createState() => _MonitorScreenState();
}

class _MonitorScreenState extends State<MonitorScreen> with WidgetsBindingObserver {
  Timer? _timer;
  bool _accessEnabled = false;
  bool _loading = true;
  String _sourceFilter = 'ทั้งหมด';
  List<FacebookEvent> _events = <FacebookEvent>[];
  List<String> _keywords = <String>[];
  final TextEditingController _keywordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refreshEvents());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _keywordController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _loadAll();
  }

  Future<void> _loadAll() async {
    final access = await NativeBridge.notificationAccessEnabled();
    final keywords = await AppStorage.loadKeywords();
    final events = await NativeBridge.getFacebookEvents();
    if (!mounted) return;
    setState(() {
      _accessEnabled = access;
      _keywords = keywords;
      _events = events;
      _loading = false;
    });
  }

  Future<void> _refreshEvents() async {
    final events = await NativeBridge.getFacebookEvents();
    if (!mounted) return;
    setState(() => _events = events);
  }

  Future<void> _addKeyword() async {
    final value = _keywordController.text.trim().toLowerCase();
    if (value.isEmpty || _keywords.contains(value)) return;
    final next = [..._keywords, value];
    await AppStorage.saveKeywords(next);
    if (!mounted) return;
    setState(() {
      _keywords = next;
      _keywordController.clear();
    });
  }

  Future<void> _removeKeyword(String keyword) async {
    final next = _keywords.where((item) => item != keyword).toList();
    await AppStorage.saveKeywords(next);
    if (!mounted) return;
    setState(() => _keywords = next);
  }

  Future<void> _clear() async {
    await NativeBridge.clearFacebookEvents();
    await _refreshEvents();
  }

  List<FacebookEvent> get _filteredEvents {
    Iterable<FacebookEvent> result = _events;
    if (_keywords.isNotEmpty) {
      result = result.where((event) => _keywords.any((keyword) => event.searchable.contains(keyword)));
    }
    if (_sourceFilter != 'ทั้งหมด') {
      result = result.where((event) => event.sourceLabel == _sourceFilter);
    }
    return result.toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _PageHeader(
          title: 'Monitor',
          subtitle: 'ติดตามประกาศจาก Marketplace และกลุ่มแบบเรียลไทม์',
          trailing: Icon(Icons.notifications, color: kFacebookBlue),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 20),
                  children: [
                    if (!_accessEnabled)
                      _PermissionBanner(onTap: NativeBridge.openNotificationSettings),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: kBorder),
                      ),
                      child: TextField(
                        controller: _keywordController,
                        onSubmitted: (_) => _addKeyword(),
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search, color: Color(0xFF51647E)),
                          hintText: 'ค้นหาคีย์เวิร์ด (เช่น DSP, Audio, Amplifier)',
                          hintStyle: const TextStyle(fontSize: 12),
                          suffixIcon: IconButton(
                            onPressed: _addKeyword,
                            icon: const Icon(Icons.add_circle, color: kFacebookBlue),
                          ),
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          filled: false,
                        ),
                      ),
                    ),
                    if (_keywords.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 34,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: _keywords.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 6),
                          itemBuilder: (context, index) {
                            final keyword = _keywords[index];
                            return InputChip(
                              label: Text(keyword),
                              labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                              onDeleted: () => _removeKeyword(keyword),
                              visualDensity: VisualDensity.compact,
                              backgroundColor: const Color(0xFFEAF3FF),
                              side: BorderSide.none,
                            );
                          },
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        _FilterButton(label: 'ราคา', icon: Icons.keyboard_arrow_down, onTap: () {}),
                        const SizedBox(width: 7),
                        _FilterButton(label: 'แหล่งที่มา', icon: Icons.keyboard_arrow_down, onTap: () {}),
                        const SizedBox(width: 7),
                        _FilterButton(label: 'คีย์เวิร์ด', icon: Icons.tune, onTap: () {}),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        for (final source in const ['ทั้งหมด', 'Marketplace', 'Group']) ...[
                          _SourceChip(
                            text: source,
                            count: _countSource(source),
                            selected: _sourceFilter == source,
                            onTap: () => setState(() => _sourceFilter = source),
                          ),
                          const SizedBox(width: 6),
                        ],
                        const Spacer(),
                        IconButton(
                          tooltip: 'ล้างประวัติ',
                          onPressed: _events.isEmpty ? null : _clear,
                          icon: const Icon(Icons.delete_outline, size: 20),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (_filteredEvents.isEmpty)
                      const _EmptyFacebookCard(
                        icon: Icons.notifications_none,
                        title: 'ยังไม่มีรายการที่ตรงคำค้น',
                        subtitle: 'รายการใหม่ที่ Facebook แจ้งเตือนจะปรากฏตรงนี้อัตโนมัติ',
                      )
                    else
                      Card(
                        child: Column(
                          children: List.generate(_filteredEvents.length, (index) {
                            final event = _filteredEvents[index];
                            return Column(
                              children: [
                                _MonitorEventRow(event: event),
                                if (index != _filteredEvents.length - 1)
                                  const Divider(height: 1, indent: 78),
                              ],
                            );
                          }),
                        ),
                      ),
                  ],
                ),
        ),
      ],
    );
  }

  int _countSource(String source) {
    final base = _keywords.isEmpty
        ? _events
        : _events.where((event) => _keywords.any((keyword) => event.searchable.contains(keyword))).toList();
    if (source == 'ทั้งหมด') return base.length;
    return base.where((event) => event.sourceLabel == source).length;
  }
}

class _PermissionBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _PermissionBanner({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF4E8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFEC84B)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Color(0xFFB54708)),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'ยังไม่ได้เปิด Notification Access',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ),
          TextButton(onPressed: onTap, child: const Text('เปิดสิทธิ์')),
        ],
      ),
    );
  }
}

class SaleDraftScreen extends StatefulWidget {
  const SaleDraftScreen({super.key});

  @override
  State<SaleDraftScreen> createState() => _SaleDraftScreenState();
}

class _SaleDraftScreenState extends State<SaleDraftScreen> {
  final _titleController = TextEditingController();
  final _priceController = TextEditingController();
  final _detailsController = TextEditingController();
  final _contactController = TextEditingController();
  bool _loaded = false;
  String _condition = 'มือสอง';
  String _contactMethod = 'Messenger (Facebook)';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final draft = await AppStorage.loadDraft();
    _titleController.text = draft.title;
    _priceController.text = draft.price;
    _detailsController.text = draft.details;
    _contactController.text = draft.contact;
    if (!mounted) return;
    setState(() {
      _condition = draft.condition;
      _contactMethod = draft.contactMethod;
      _loaded = true;
    });
  }

  SaleDraft _currentDraft() => SaleDraft(
        title: _titleController.text,
        price: _priceController.text,
        condition: _condition,
        details: _detailsController.text,
        contact: _contactController.text,
        contactMethod: _contactMethod,
      );

  Future<void> _save() async {
    await AppStorage.saveDraft(_currentDraft());
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('บันทึกร่างสินค้าแล้ว')),
    );
  }

  Future<void> _share() async {
    final draft = _currentDraft();
    final text = draft.composePost();
    if (text.trim().isEmpty) return;
    await AppStorage.saveDraft(draft);
    await NativeBridge.shareText(text);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _priceController.dispose();
    _detailsController.dispose();
    _contactController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _PageHeader(
          title: 'ลงขาย',
          subtitle: 'เตรียมโพสต์ของคุณให้พร้อม ก่อนนำไปลงในกลุ่ม',
          trailing: OutlinedButton.icon(
            onPressed: _loaded ? _save : null,
            icon: const Icon(Icons.save_outlined, size: 17),
            label: const Text('บันทึกร่าง'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              visualDensity: VisualDensity.compact,
            ),
          ),
        ),
        Expanded(
          child: !_loaded
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
                  children: [
                    const Text('รูปภาพสินค้า (0/10)', style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    InkWell(
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('ระบบเลือกรูปจะเพิ่มใน V3')),
                        );
                      },
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        height: 132,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFB9C1CC), style: BorderStyle.solid),
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.add_a_photo_outlined, color: Color(0xFF7A8AA0), size: 36),
                            SizedBox(height: 8),
                            Text('แตะเพื่อเพิ่มรูปภาพ', style: TextStyle(fontWeight: FontWeight.w700)),
                            Text('(สูงสุด 10 รูป)', style: TextStyle(color: kTextSecondary, fontSize: 11)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    _FieldLabel('ชื่อสินค้า', required: true),
                    TextField(
                      controller: _titleController,
                      decoration: const InputDecoration(hintText: 'เช่น DSP ALPINE PXE-R600 สภาพสวย'),
                    ),
                    const SizedBox(height: 12),
                    _FieldLabel('ราคา (บาท)', required: true),
                    TextField(
                      controller: _priceController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: 'เช่น 12500'),
                    ),
                    const SizedBox(height: 12),
                    _FieldLabel('สภาพสินค้า'),
                    DropdownButtonFormField<String>(
                      value: _condition,
                      items: const ['มือสอง', 'ใหม่', 'เหมือนใหม่', 'มีตำหนิ']
                          .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                          .toList(),
                      onChanged: (value) => setState(() => _condition = value ?? _condition),
                    ),
                    const SizedBox(height: 12),
                    _FieldLabel('รายละเอียดสินค้า', required: true),
                    TextField(
                      controller: _detailsController,
                      maxLines: 5,
                      decoration: const InputDecoration(
                        hintText: 'ระบุรายละเอียดสินค้า สภาพการใช้งาน อุปกรณ์ที่มี เหตุผลในการขาย เป็นต้น',
                      ),
                    ),
                    const SizedBox(height: 12),
                    _FieldLabel('ช่องทางการติดต่อ', required: true),
                    ...['Messenger (Facebook)', 'LINE', 'เบอร์โทรศัพท์', 'อื่นๆ'].map(
                      (method) => RadioListTile<String>(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        value: method,
                        groupValue: _contactMethod,
                        onChanged: (value) => setState(() => _contactMethod = value ?? _contactMethod),
                        title: Text(method, style: const TextStyle(fontSize: 13)),
                        activeColor: kFacebookBlue,
                      ),
                    ),
                    TextField(
                      controller: _contactController,
                      decoration: const InputDecoration(hintText: 'รายละเอียดช่องทางติดต่อ (ถ้ามี)'),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEAF3FF),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'เครื่องมือช่วยโพสต์',
                            style: TextStyle(color: Color(0xFF104FA3), fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: FilledButton.icon(
                                  onPressed: _share,
                                  icon: const Icon(Icons.copy_all_outlined),
                                  label: const Text('คัดลอก/แชร์ข้อความ'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () async {
                                    await _save();
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('บันทึกร่างแล้ว ไปที่เมนู “กลุ่ม” เพื่อเลือกกลุ่มที่จะโพสต์')),
                                    );
                                  },
                                  icon: const Icon(Icons.open_in_new),
                                  label: const Text('เตรียมไปลงกลุ่ม'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF4D8),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.lightbulb_outline, color: Color(0xFFB54708), size: 20),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'แอปจะช่วยเตรียมและคัดลอกโพสต์ให้ แต่การกดโพสต์ขั้นสุดท้ายทำใน Facebook เพื่อให้ใช้งานได้เสถียรกว่า',
                              style: TextStyle(fontSize: 11, color: Color(0xFF7A2E0E)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ],
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  final bool required;
  const _FieldLabel(this.text, {this.required = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: kTextPrimary, fontSize: 13, fontWeight: FontWeight.w800),
          children: [
            TextSpan(text: text),
            if (required) const TextSpan(text: ' *', style: TextStyle(color: Color(0xFFD92D20))),
          ],
        ),
      ),
    );
  }
}

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  List<GroupTarget> _groups = <GroupTarget>[];
  bool _loading = true;
  bool _hasDraft = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final groups = await AppStorage.loadGroups();
    final draft = await AppStorage.loadDraft();
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _hasDraft = draft.title.trim().isNotEmpty;
      _loading = false;
    });
  }

  Future<void> _addGroup() async {
    final nameController = TextEditingController();
    final urlController = TextEditingController(text: 'https://www.facebook.com/groups/');
    final result = await showDialog<GroupTarget>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('เพิ่มกลุ่ม Facebook'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'ชื่อกลุ่ม')),
            const SizedBox(height: 10),
            TextField(controller: urlController, decoration: const InputDecoration(labelText: 'ลิงก์กลุ่ม')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('ยกเลิก')),
          FilledButton(
            onPressed: () {
              final name = nameController.text.trim();
              final url = urlController.text.trim();
              if (name.isEmpty || !url.startsWith('http')) return;
              Navigator.pop(context, GroupTarget(name: name, url: url));
            },
            child: const Text('เพิ่ม'),
          ),
        ],
      ),
    );
    nameController.dispose();
    urlController.dispose();
    if (result == null) return;
    final next = [..._groups, result];
    await AppStorage.saveGroups(next);
    if (!mounted) return;
    setState(() => _groups = next);
  }

  Future<void> _deleteGroup(int index) async {
    final next = [..._groups]..removeAt(index);
    await AppStorage.saveGroups(next);
    if (!mounted) return;
    setState(() => _groups = next);
  }

  Future<void> _openForPosting(GroupTarget group) async {
    final draft = await AppStorage.loadDraft();
    final post = draft.composePost();
    if (post.trim().isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('กรุณาสร้าง Draft สินค้าก่อน')),
      );
      return;
    }
    await Clipboard.setData(ClipboardData(text: post));
    await NativeBridge.openUrl(group.url);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('คัดลอกข้อความแล้ว เปิดกลุ่มเพื่อวางและกดโพสต์ได้เลย')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _PageHeader(
          title: 'กลุ่ม',
          subtitle: 'จัดการกลุ่ม Facebook ของคุณ',
          trailing: OutlinedButton.icon(
            onPressed: _addGroup,
            icon: const Icon(Icons.group_add_outlined, size: 17),
            label: const Text('เพิ่มกลุ่ม'),
            style: OutlinedButton.styleFrom(
              visualDensity: VisualDensity.compact,
              padding: const EdgeInsets.symmetric(horizontal: 9),
            ),
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'กลุ่มของฉัน (${_groups.length})',
                              style: const TextStyle(color: kFacebookBlue, fontWeight: FontWeight.w800),
                            ),
                          ),
                          TextButton(onPressed: _addGroup, child: const Text('ค้นหากลุ่มใหม่')),
                        ],
                      ),
                      const Divider(height: 1, color: kFacebookBlue),
                      const SizedBox(height: 8),
                      if (_groups.isEmpty)
                        const _EmptyFacebookCard(
                          icon: Icons.groups_outlined,
                          title: 'ยังไม่ได้เพิ่มกลุ่ม',
                          subtitle: 'เพิ่มชื่อและลิงก์กลุ่ม Facebook ที่คุณเป็นสมาชิกก่อน',
                        )
                      else
                        Card(
                          child: Column(
                            children: List.generate(_groups.length, (index) {
                              final group = _groups[index];
                              return Column(
                                children: [
                                  _GroupRow(
                                    group: group,
                                    hasDraft: _hasDraft,
                                    onOpen: () => _openForPosting(group),
                                    onDelete: () => _deleteGroup(index),
                                  ),
                                  if (index != _groups.length - 1)
                                    const Divider(height: 1, indent: 74),
                                ],
                              );
                            }),
                          ),
                        ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'คิวโพสต์ (${_hasDraft ? _groups.length : 0})',
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                            ),
                          ),
                          TextButton(onPressed: _load, child: const Text('จัดการคิว')),
                        ],
                      ),
                      const SizedBox(height: 6),
                      if (!_hasDraft)
                        const _EmptyFacebookCard(
                          icon: Icons.inventory_2_outlined,
                          title: 'ยังไม่มี Draft สำหรับโพสต์',
                          subtitle: 'สร้างสินค้าในเมนู “ลงขาย” แล้วคิวโพสต์จะขึ้นที่นี่',
                        )
                      else if (_groups.isEmpty)
                        const _EmptyFacebookCard(
                          icon: Icons.group_add_outlined,
                          title: 'Draft พร้อมแล้ว แต่ยังไม่มีกลุ่ม',
                          subtitle: 'เพิ่มกลุ่มอย่างน้อย 1 กลุ่มเพื่อเริ่มคิวโพสต์',
                        )
                      else
                        Card(
                          child: Column(
                            children: List.generate(_groups.length, (index) {
                              final group = _groups[index];
                              return Column(
                                children: [
                                  ListTile(
                                    leading: Container(
                                      width: 48,
                                      height: 48,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFEAF3FF),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(Icons.sell_outlined, color: kFacebookBlue),
                                    ),
                                    title: Text(group.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                    subtitle: const Text('รอโพสต์', style: TextStyle(color: Color(0xFFB54708))),
                                    trailing: OutlinedButton(
                                      onPressed: () => _openForPosting(group),
                                      child: const Text('โพสต์'),
                                    ),
                                  ),
                                  if (index != _groups.length - 1)
                                    const Divider(height: 1, indent: 74),
                                ],
                              );
                            }),
                          ),
                        ),
                    ],
                  ),
                ),
        ),
      ],
    );
  }
}

class _GroupRow extends StatelessWidget {
  final GroupTarget group;
  final bool hasDraft;
  final VoidCallback onOpen;
  final VoidCallback onDelete;

  const _GroupRow({
    required this.group,
    required this.hasDraft,
    required this.onOpen,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF3FF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.groups, color: kFacebookBlue),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(group.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(
                  hasDraft ? 'มี Draft พร้อมโพสต์' : 'ยังไม่มี Draft',
                  style: TextStyle(
                    color: hasDraft ? const Color(0xFF16834B) : kTextSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton(onPressed: onOpen, child: const Text('เปิดกลุ่ม')),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'delete') onDelete();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'delete', child: Text('ลบกลุ่ม')),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String actionText;
  final VoidCallback onTap;

  const _SectionTitle({required this.title, required this.actionText, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
        TextButton(onPressed: onTap, child: Text(actionText)),
      ],
    );
  }
}

class _FilterButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _FilterButton({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: kBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
            const SizedBox(width: 3),
            Icon(icon, size: 16),
          ],
        ),
      ),
    );
  }
}

class _SourceChip extends StatelessWidget {
  final String text;
  final int count;
  final bool selected;
  final VoidCallback onTap;

  const _SourceChip({required this.text, required this.count, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFEAF3FF) : Colors.white,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: selected ? kFacebookBlue : kBorder),
        ),
        child: Text(
          '$text ($count)',
          style: TextStyle(
            fontSize: 11,
            color: selected ? kFacebookBlue : kTextSecondary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

class _CompactEventRow extends StatelessWidget {
  final FacebookEvent event;
  final List<String> keywords;
  const _CompactEventRow({required this.event, required this.keywords});

  @override
  Widget build(BuildContext context) {
    String? keyword;
    for (final item in keywords) {
      if (event.searchable.contains(item)) {
        keyword = item;
        break;
      }
    }

    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProductThumb(source: event.sourceLabel),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.title.trim().isEmpty ? 'Facebook Notification' : event.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
                ),
                if (event.text.trim().isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(event.text, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: kTextSecondary)),
                ],
                const SizedBox(height: 6),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: [
                    _MiniTag(event.sourceLabel, source: true),
                    if (keyword != null) _MiniTag('คีย์เวิร์ด: $keyword'),
                  ],
                ),
              ],
            ),
          ),
          const Icon(Icons.bookmark_border, size: 19, color: Color(0xFF51647E)),
        ],
      ),
    );
  }
}

class _MonitorEventRow extends StatelessWidget {
  final FacebookEvent event;
  const _MonitorEventRow({required this.event});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProductThumb(source: event.sourceLabel),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event.title.trim().isEmpty ? 'Facebook Notification' : event.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
                ),
                const SizedBox(height: 3),
                Text(
                  event.text.trim().isEmpty ? 'มีการแจ้งเตือนใหม่จาก Facebook' : event.text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: kTextSecondary, fontSize: 11),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    _MiniTag(event.sourceLabel, source: true),
                    const SizedBox(width: 5),
                    Text(_timeAgo(event.timestamp), style: const TextStyle(fontSize: 10, color: kTextSecondary)),
                  ],
                ),
              ],
            ),
          ),
          const Icon(Icons.more_vert, size: 19, color: Color(0xFF51647E)),
        ],
      ),
    );
  }
}

class _ProductThumb extends StatelessWidget {
  final String source;
  const _ProductThumb({required this.source});

  @override
  Widget build(BuildContext context) {
    final group = source == 'Group';
    return Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        color: group ? const Color(0xFFECFDF3) : const Color(0xFFEAF3FF),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(
        group ? Icons.groups : Icons.speaker_group_outlined,
        color: group ? const Color(0xFF16834B) : kFacebookBlue,
        size: 29,
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  final String text;
  final bool source;
  const _MiniTag(this.text, {this.source = false});

  @override
  Widget build(BuildContext context) {
    final isGroup = text == 'Group';
    final background = source
        ? (isGroup ? const Color(0xFFDCFCE7) : const Color(0xFFDCEEFF))
        : const Color(0xFFF1F3F5);
    final foreground = source
        ? (isGroup ? const Color(0xFF16834B) : const Color(0xFF125BB5))
        : const Color(0xFF667085);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(5)),
      child: Text(text, style: TextStyle(color: foreground, fontSize: 9, fontWeight: FontWeight.w700)),
    );
  }
}

class _EmptyFacebookCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyFacebookCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
        child: Column(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: const BoxDecoration(color: Color(0xFFEAF3FF), shape: BoxShape.circle),
              child: Icon(icon, color: kFacebookBlue, size: 28),
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: kTextSecondary, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

String _timeAgo(int millis) {
  if (millis <= 0) return 'เมื่อสักครู่';
  final date = DateTime.fromMillisecondsSinceEpoch(millis).toLocal();
  final diff = DateTime.now().difference(date);
  if (diff.inMinutes < 1) return 'เมื่อสักครู่';
  if (diff.inMinutes < 60) return '${diff.inMinutes} นาทีที่แล้ว';
  if (diff.inHours < 24) return '${diff.inHours} ชั่วโมงที่แล้ว';
  return '${diff.inDays} วันที่แล้ว';
}
