OKN_MARKET V2
==============

รุ่นนี้ปรับหน้าตาแอปใหม่ตาม mockup ที่ผู้ใช้เลือก โดยยังคงระบบหลักจาก V1

หน้าจอหลัก
1) ภาพรวม
   - Header OKN_MARKET แบบ Facebook-inspired
   - การ์ดสถิติ 4 ช่อง
   - รายการ Notification ล่าสุดแบบ feed

2) Monitor
   - ช่องค้นหา/เพิ่มคีย์เวิร์ด
   - Chip คีย์เวิร์ด
   - Filter ทั้งหมด / Marketplace / Group
   - Feed Notification แบบรายการสินค้า
   - Refresh อัตโนมัติทุก 2 วินาที

3) ลงขาย
   - ฟอร์มชื่อสินค้า ราคา สภาพ รายละเอียด ติดต่อ
   - บันทึกร่าง
   - สร้าง/แชร์ข้อความขาย
   - เตรียมร่างสำหรับนำไปโพสต์ในกลุ่ม
   - ช่องรูปภาพใน V2 เป็น UI placeholder (ตัวเลือกรูปจริงจะทำใน V3)

4) กลุ่ม
   - เพิ่ม/ลบกลุ่ม Facebook
   - เปิดกลุ่มจากลิงก์
   - คัดลอก Draft ล่าสุดก่อนเปิดกลุ่ม
   - แสดงคิวโพสต์ตามกลุ่มที่บันทึก

ระบบ Native Android เดิม
- NotificationListenerService รับ notification จาก Facebook/Facebook Lite/Messenger
- เก็บ notification สูงสุด 200 รายการ
- MethodChannel ใช้เปิด Notification Settings, เปิด URL และ Share text

หมายเหตุสำคัญ
- V2 ไม่ scrape Facebook Marketplace โดยตรง
- V2 ไม่ใช้ bot กดโพสต์อัตโนมัติ
- ขั้นตอนกดโพสต์สุดท้ายทำใน Facebook โดยผู้ใช้

Build
- ใช้ build-okn-market.yml เดิมได้
- วาง OKN_MARKET_V2_SOURCE.zip ไว้ root ของ GitHub repo
- workflow จะเลือกรุ่น V ล่าสุดและ build APK ให้อัตโนมัติ
