package com.okn.okn_market

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class MarketNotificationListenerService : NotificationListenerService() {

    companion object {
        const val PREFS_NAME = "okn_market_monitor_native"
        const val EVENTS_KEY = "facebook_events"
        private const val MAX_EVENTS = 200
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        val packageName = sbn.packageName ?: return
        if (!isFacebookPackage(packageName)) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = bestNotificationText(extras)

        if (title.isBlank() && text.isBlank()) return

        val event = JSONObject().apply {
            put("id", sbn.key ?: "${packageName}_${sbn.postTime}")
            put("package", packageName)
            put("title", title)
            put("text", text)
            put("timestamp", sbn.postTime)
        }

        saveEvent(event)
    }

    private fun isFacebookPackage(packageName: String): Boolean {
        return packageName == "com.facebook.katana" ||
            packageName == "com.facebook.lite" ||
            packageName == "com.facebook.orca"
    }

    private fun bestNotificationText(extras: android.os.Bundle): String {
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        if (!bigText.isNullOrBlank()) return bigText

        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        if (!text.isNullOrBlank()) return text

        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        if (!lines.isNullOrEmpty()) {
            return lines.joinToString("\n") { it.toString() }
        }

        return ""
    }

    private fun saveEvent(event: JSONObject) {
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val currentRaw = prefs.getString(EVENTS_KEY, "[]") ?: "[]"
        val current = try {
            JSONArray(currentRaw)
        } catch (_: Exception) {
            JSONArray()
        }

        val next = JSONArray()
        val newId = event.optString("id")
        next.put(event)

        var index = 0
        while (index < current.length() && next.length() < MAX_EVENTS) {
            val item = current.optJSONObject(index)
            if (item != null && item.optString("id") != newId) {
                next.put(item)
            }
            index++
        }

        prefs.edit().putString(EVENTS_KEY, next.toString()).apply()
    }
}
