package com.okn.okn_market

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.okn.okn_market/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "notificationAccessEnabled" -> {
                    result.success(isNotificationListenerEnabled())
                }

                "openNotificationSettings" -> {
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        result.success(null)
                    } catch (error: Exception) {
                        result.error("SETTINGS_ERROR", error.message, null)
                    }
                }

                "getFacebookNotifications" -> {
                    val prefs = getSharedPreferences(
                        MarketNotificationListenerService.PREFS_NAME,
                        MODE_PRIVATE
                    )
                    result.success(
                        prefs.getString(
                            MarketNotificationListenerService.EVENTS_KEY,
                            "[]"
                        ) ?: "[]"
                    )
                }

                "clearFacebookNotifications" -> {
                    getSharedPreferences(
                        MarketNotificationListenerService.PREFS_NAME,
                        MODE_PRIVATE
                    ).edit()
                        .putString(MarketNotificationListenerService.EVENTS_KEY, "[]")
                        .apply()
                    result.success(null)
                }

                "openUrl" -> {
                    val url = call.argument<String>("url")?.trim().orEmpty()
                    if (url.isBlank()) {
                        result.error("INVALID_URL", "URL is empty", null)
                    } else {
                        openUrl(url, result)
                    }
                }

                "shareText" -> {
                    val text = call.argument<String>("text").orEmpty()
                    shareText(text, result)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val component = ComponentName(this, MarketNotificationListenerService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false

        return enabled.split(":").any { entry ->
            entry.equals(component.flattenToString(), ignoreCase = true) ||
                entry.equals(component.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun openUrl(url: String, result: MethodChannel.Result) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            result.success(null)
        } catch (error: Exception) {
            result.error("OPEN_URL_ERROR", error.message, null)
        }
    }

    private fun shareText(text: String, result: MethodChannel.Result) {
        if (text.isBlank()) {
            result.error("EMPTY_TEXT", "Text is empty", null)
            return
        }

        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }

        try {
            val facebookIntent = Intent(baseIntent).apply {
                setPackage("com.facebook.katana")
            }
            startActivity(facebookIntent)
            result.success(null)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent.createChooser(baseIntent, "แชร์ข้อความขาย"))
                result.success(null)
            } catch (error: Exception) {
                result.error("SHARE_ERROR", error.message, null)
            }
        }
    }
}
